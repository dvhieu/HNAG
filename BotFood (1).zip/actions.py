from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

from rasa_core_sdk import Action
from rasa_core_sdk.events import SlotSet
from rasa_core_sdk.events import UserUtteranceReverted
from rasa_core_sdk.events import AllSlotsReset
from rasa_core_sdk.events import Restarted

import requests
import json
from bs4 import BeautifulSoup
from pyvi import ViTokenizer, ViPosTagger

from underthesea import sentiment 

def name_cap(text):
    tarr = text.split()
    for idx in range(len(tarr)):
        tarr[idx] = tarr[idx].capitalize()
    return ' '.join(tarr)

class action_save_cust_info(Action):
    def name(self):
        return 'action_save_cust_info'

    def run(self, dispatcher, tracker, domain):
        user_id = (tracker.current_state())["sender_id"]
        print(user_id)
        cust_name = next(tracker.get_latest_entity_values("cust_name"), None)
        cust_sex = next(tracker.get_latest_entity_values("cust_sex"), None)
        bot_position = "SHB"

        if (cust_sex is  None):
            cust_sex = "Quý khách"

        if (cust_sex == "anh") | (cust_sex == "chị"):
           bot_position = "em"
        elif (cust_sex == "cô") | (cust_sex == "chú"):
            bot_position = "cháu"
        else:
            cust_sex = "Quý khách"
            bot_position = "SHB"

        if not cust_name:
            #dispatcher.utter_template("utter_greet_name",tracker)
            return []

        print (name_cap(cust_name))
        return [SlotSet('cust_name', " "+name_cap(cust_name)),SlotSet('cust_sex', name_cap(cust_sex)),SlotSet('bot_position', name_cap(bot_position))]

class action_save_mobile_no(Action):
    def name(self):
        return 'action_save_mobile_no'

    def run(self, dispatcher, tracker, domain):
        user_id = (tracker.current_state())["sender_id"]
        print(user_id)
        mobile_no = next(tracker.get_latest_entity_values("inp_number"), None)

        if not mobile_no:
            return  [UserUtteranceReverted()]

        mobile_no = mobile_no.replace(" ","")
        #print (cust_name)
        return [SlotSet('mobile_no', mobile_no)]

class action_reset_slot(Action):

    def name(self):
        return "action_reset_slot"

    def run(self, dispatcher, tracker, domain):
        return [SlotSet("transfer_nick", None),SlotSet("transfer_amount", None),SlotSet("transfer_amount_unit", None)]

class review_produce(Action):
    def name(self):
      return "review_produce"

    def run(self, dispatcher, tracker, domain):
        last_message = tracker.latest_message.get("text", "")
      
        rs = sentiment(last_message)
        
        msg = ""

        if (rs == "negative"):
            msg = "Xin lỗi quý khách vì đã làm quý khách cảm thấy khó chịu với sản phẩm bên mình :< mình thật lòng xin lỗi, hiện shop đang cải thiện dần ạ :<"

        else:
            msg = "Cảm ơn quý khách đã đánh giá sản phẩm, hi vọng lần sau quý khách sẽ đến mua tiếp ạ :>"

        dispatcher.utter_message(msg)

        return []

class get_food_for_lunch(Action):
    def name(self):
          return 'get_food_for_lunch'

    def run(self, dispatcher, tracker, domain):

        f = open("data.json","r", encoding="utf8").read()

        data = json.loads(f)

        msg = "";

        if (len(data["lunch"])==0):
            msg = "Hiện tại mình không thể đề suất các món bữa trưa cho bạn được :< Xin lỗi bạn nhé!, hi vọng lần sau bạn hỏi mình sẽ có nhiều món đặc biệt để khiến bạn cảm thấy vui vẻ hơn :>"
        else:
            msg = "Bữa trưa quan trọng lắm đấy :>, sau đây là những món mà bạn có thể chọn nè :> hihi :>\n"

        for i in range(0,min(len(data["lunch"]),3)):
            msg += "\nMón {}: {} \n{}\n".format(data["lunch"][i]["name"],data["lunch"][i]["price"], data["lunch"][i]["Description"])
        
        dispatcher.utter_message(msg)

        return []

class get_food_for_vegetarian(Action):
    def name(self):
          return 'get_food_for_vegetarian'

    def run(self, dispatcher, tracker, domain):

        f = open("data.json","r", encoding="utf8").read()

        data = json.loads(f)

        msg = "";

        if (len(data["vegetarian"])==0):
            msg = "Xin chào người bạn ăn chay của mình! hiện mình chưa thể đề suất cho bạn các món ăn chay được :< xin lỗi bạn nhiều nha :<, hi vọng lần sau bạn ghé thăm mình sẽ gợi ý cho bạn những món ăn chay tuyệt vời :>"
        else:
            msg = "Xin chào người bạn ăn chay :>, sau đây là những món mình nghĩ bạn có thể dùng đấy :>\n"

        for i in range(0,min(len(data["vegetarian"]),3)):
            msg += "\nMón {}: {} \n{}\n".format(data["vegetarian"][i]["name"],data["vegetarian"][i]["price"], data["vegetarian"][i]["Description"])
        
        dispatcher.utter_message(msg)

        return []

class get_food_for_eat(Action):
    def name(self):
          return 'get_food_for_eat'

    def run(self, dispatcher, tracker, domain):

        f = open("data.json","r", encoding="utf8").read()

        data = json.loads(f)

        msg = "";

        if (len(data["eat"])==0):
            msg = "Mình muốn gợi ý cho bạn những món ngon cơ :< nhưng hiện tại mình chưa có chút thông tin gì các món ngon để gợi ý cho bạn :< hi vọng lần sau sẽ có những món tuyệt vời được gợi ý đó nha :>"
        else:
            msg = "Dưới đây là những món ăn tuyệt vời :>\n"

        for i in range(0,min(len(data["eat"]),3)):
            msg += "\nMón {}: {} \n{}\n".format(data["eat"][i]["name"],data["eat"][i]["price"], data["eat"][i]["Description"])
        
        dispatcher.utter_message(msg)

        return []

class get_food_for_summer(Action):
    def name(self):
          return 'get_food_for_summer'

    def run(self, dispatcher, tracker, domain):

        f = open("data.json","r", encoding="utf8").read()

        data = json.loads(f)

        msg = "";

        if (len(data["summer"])==0):
            msg = "Mùa hè nóng nực, mặt trời đổ lửa :<, nhưng mình không biết nên khuyên bạn ăn gì :< huhu"
        else:
            msg = "Mùa hè thật là nóng, nóng như thế này thì đã có các món sau đây giải nhiệt, đánh bay mùa hè nóng nực :>\n"

        for i in range(0,min(len(data["summer"]),3)):
            msg += "\nMón {}: {} \n{}\n".format(data["summer"][i]["name"],data["summer"][i]["price"], data["summer"][i]["Description"])
        
        dispatcher.utter_message(msg)

        return []


class get_food_for_cold(Action):
    def name(self):
          return 'get_food_for_cold'

    def run(self, dispatcher, tracker, domain):

        f = open("data.json","r", encoding="utf8").read()

        data = json.loads(f)

        msg = "";

        if (len(data["cold"])==0):
            msg = "Lạnh quá đi :<, có thể bạn sẽ cảm lạnh đấy :< xin lỗi bạn nhưng hiện giờ mình không thể gợi ý cho bạn được huhu :<"
        else:
            msg = "Lạnh quá đi, lạnh quá đi!\nSau đay là các món giúp bạn có một cơ thể ấm hơn nè :>\n"

        for i in range(0,min(len(data["cold"]),3)):
            msg += "\nMón {}: {} \n{}\n".format(data["cold"][i]["name"],data["cold"][i]["price"], data["cold"][i]["Description"])
        
        dispatcher.utter_message(msg)

        return []

class  get_food_for_people_lose_weight(Action):
    def name(self):
          return 'get_food_for_people_lose_weight'

    def run(self, dispatcher, tracker, domain):

        f = open("data.json","r", encoding="utf8").read()

        data = json.loads(f)

        msg = "";

        if (len(data["lose_weight"])==0):
            msg = "Mình cũng muốn giảm cân nữa :<, nhưng mình cũng như bạn thôi không biết nên chọn món nào"
        else:
            msg = "Giảm cân thôi! Quyết tâm giảm cân hehe :>\n"

        for i in range(0,min(len(data["lose_weight"]),3)):
            msg += "\nMón {}: {} \n{}\n".format(data["lose_weight"][i]["name"],data["lose_weight"][i]["price"], data["lose_weight"][i]["Description"])
        
        dispatcher.utter_message(msg)

        return []

class get_food_for_people_health_and_balance(Action):
    def name(self):
          return 'get_food_for_people_health_and_balance'

    def run(self, dispatcher, tracker, domain):

        f = open("data.json","r", encoding="utf8").read()

        data = json.loads(f)

        msg = "";

        if (len(data["health_and_balance"])==0):
            msg = "Ăn món gì cho health và balance đây :<, mình cũng đang tự hỏi câu đó :< huhu hiện mình không nghĩ ra nên ăn gì hết :< xin lỗi bạn nha!"
        else:
            msg = "Ăn món gì cho phù hợp sức khoẻ nhỉ :> \nCâu hỏi khó đã có mình lo phần trả lời cho, sau đây là các món ăn giúp cơ thể bạn khoẻ mạnh hơn!\n"

        for i in range(0,min(len(data["health_and_balance"]),3)):
            msg += "\nMón {}: {} \n{}\n".format(data["health_and_balance"][i]["name"],data["health_and_balance"][i]["price"], data["health_and_balance"][i]["Description"])
        
        dispatcher.utter_message(msg)

        return []


class get_food_with_sugar(Action):
    def name(self):
          return 'get_food_with_sugar'

    def run(self, dispatcher, tracker, domain):

        f = open("data.json","r", encoding="utf8").read()

        data = json.loads(f)

        msg = "";

        if (len(data["with_sugar"])==0):
            msg = "Ôi món ăn ngọt, mình thích lắm, nhưng hiện tại không thể gợi ý cho bạn được rồi :< buồn ghê"
        else:
            msg = "Món ngọt nè, món ngọt nè!\n"

        for i in range(0,min(len(data["with_sugar"]),3)):
            msg += "\nMón {}: {} \n{}\n".format(data["with_sugar"][i]["name"],data["with_sugar"][i]["price"], data["with_sugar"][i]["Description"])
        
        dispatcher.utter_message(msg)

        return []


class get_food_for_new_year(Action):
    def name(self):
          return 'get_food_for_new_year'

    def run(self, dispatcher, tracker, domain):

        f = open("data.json","r", encoding="utf8").read()

        data = json.loads(f)

        msg = "";
        
        if (len(data["new_year"])==0):
            msg = "Happy new year :>, hiện mình không thể giúp bạn chọn món được rồi :> vì mình bận đi chơi xuân rồi :>"
        else:
            msg = "Happy new year, một cái tết no ấm là không thể thiếu các món sau đây đâu nha!\n"

        for i in range(0,min(len(data["new_year"]),3)):
            msg += "\nMón {}: {} \n{}\n".format(data["new_year"][i]["name"],data["new_year"][i]["price"], data["new_year"][i]["Description"])
        
        dispatcher.utter_message(msg)

        return []


class get_food_for_night(Action):
    def name(self):
          return 'get_food_for_night'

    def run(self, dispatcher, tracker, domain):

        f = open("data.json","r", encoding="utf8").read()

        data = json.loads(f)

        msg = "";

        if (len(data["night"])==0):
            msg = "Trời tối rồi :< mà mình không thể gợi ý cho bạn ăn gì :< buồn quá đi :< thôi mình đi ngủ đây :< huhu"
        else:
            msg = "Trời tối rồi, ăn thôi nào, mở tiệc thôi nào :>\n"

        for i in range(0,min(len(data["night"]),3)):
            msg += "\nMón {}: {} \n{}\n".format(data["night"][i]["name"],data["night"][i]["price"], data["night"][i]["Description"])
        
        dispatcher.utter_message(msg)

        return []


class get_food_for_breakfast(Action):
    def name(self):
          return 'get_food_for_breakfast'

    def run(self, dispatcher, tracker, domain):

        f = open("data.json","r", encoding="utf8").read()

        data = json.loads(f)

        msg = "";
        
        if (len(data["breakfast"])==0):
            msg = "Trời sáng rồi :> dậy tập thể dục nào :< à mà khoan đã mình không biết có món gì ngon không nữa :< thôi mình ngủ lại vậy!"
        else:
            msg = "Bữa sáng rất quan trọng đó, tập thể dục xong chúng ta cùng bổ sung năng lượng cho một ngày mới với các món sau đây nào :>\n"

        for i in range(0,min(len(data["breakfast"]),3)):
            msg += "\nMón {}: {} \n{}\n".format(data["breakfast"][i]["name"],data["breakfast"][i]["price"], data["breakfast"][i]["Description"])
        
        dispatcher.utter_message(msg)

        return []