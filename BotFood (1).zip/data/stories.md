## review food
* review
  - review_produce

## ask lunch
* ask_for_lunch
  - get_food_for_lunch

## ask recommend
* ask_for_eat
  - get_food_for_eat

## ask vegetarian
* ask_for_vegetarian
  - get_food_for_vegetarian

## ask summer
* ask_for_summer
  - get_food_for_summer

## ask cold
* ask_for_cold
  - get_food_for_cold

## ask people_lose_weight
* ask_for_people_lose_weight
  - get_food_for_people_lose_weight

## ask people_health_and_balance
* ask_for_people_health_and_balance
  - get_food_for_people_health_and_balance

## ask with_sugar
* ask_food_with_sugar
  - get_food_with_sugar

## ask new_year
* ask_for_new_year
  - get_food_for_new_year

## ask night
* ask_for_night
  - get_food_for_night

## ask breakfast
* ask_for_breakfast
  - get_food_for_breakfast

## Chào hỏi đưa tên
* greet
  - utter_greet
* give_name
  - utter_greet_with_name
  - action_save_cust_info
* ask_name
  - utter_ask_name
* bye
  - utter_bye

## Đưa tên luôn
* give_name
  - utter_greet_with_name

## Chào - tên - hỏi chức năng - chào
* greet
  - utter_greet
* ask_name
  - utter_ask_name
* ask_func_list
  - utter_func_list
* bye
  - utter_bye
  
## Chào  - hỏi chức năng - chào
* greet
  - utter_greet
* ask_func_list
  - utter_func_list
* bye
  - utter_bye

## Chào  - hỏi tên - chào
* greet
  - utter_greet
* ask_name
  - utter_ask_name
* bye
  - utter_bye

## Hỏi tên - hỏi chức năng
* ask_name
  - utter_ask_name
* ask_func_list
  - utter_func_list

## Cảm ơn
* thank
  - utter_thank